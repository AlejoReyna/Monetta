// D02 — fonts actually used by the renderer, tokens and wordmark.
import { assert } from './report.mjs';

async function platformFonts(page, selector) {
  const client = await page.context().newCDPSession(page);
  await client.send('DOM.enable');
  await client.send('CSS.enable');
  const { root } = await client.send('DOM.getDocument', { depth: -1 });
  const { nodeId } = await client.send('DOM.querySelector', { nodeId: root.nodeId, selector });
  assert(nodeId, `no node for ${selector}`);
  const { fonts } = await client.send('CSS.getPlatformFontsForNode', { nodeId });
  await client.detach();
  return fonts.map((font) => `${font.familyName}${font.isCustomFont ? ' (web font)' : ''}`);
}

export async function checkIdentity({ browser, url, report }) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  report.trackPage(page, 'identity');
  await page.goto(`${url}/`, { waitUntil: 'networkidle' });
  await page.evaluate(() => document.fonts.ready);

  await report.step('D02', 'Web fonts load in the weights the design uses', async () => {
    const faces = await page.evaluate(() => [...document.fonts].map((face) => `${face.family.replace(/"/g, '')} ${face.weight} ${face.status}`));
    const expected = ['Inter 400 loaded', 'Inter 500 loaded', 'Inter 600 loaded', 'Inter 700 loaded', 'Playfair Display 400 loaded'];
    for (const face of expected) assert(faces.includes(face), `${face} not found in ${faces.join(', ')}`);
    return faces.join(' · ');
  });

  const roles = [
    ['Section heading (Novedades)', '#home-novedades', 'Playfair Display'],
    ['Product card brand', '.card__brand', 'Inter'],
    ['Product card name', '.card__name', 'Inter'],
    ['Product card price', '.card__price .price', 'Inter'],
    ['Category navigation', '.site-nav__link', 'Inter'],
    ['Primary button', '.home-hero__actions .btn--primary', 'Inter'],
  ];
  for (const [label, selector, family] of roles) {
    await report.step('D02', `Renderer uses ${family} for: ${label}`, async () => {
      const used = await platformFonts(page, selector);
      assert(used.length && used.every((name) => name.startsWith(family)), `${selector} rendered with ${used.join(', ')}`);
      return used.join(', ');
    });
  }

  await report.step('D02', 'Computed tokens match the boutique palette and geometry', async () => {
    const values = await page.evaluate(() => {
      const style = (selector, property) => getComputedStyle(document.querySelector(selector))[property];
      return {
        canvas: style('body', 'backgroundColor'),
        ink: style('body', 'color'),
        eyebrow: style('.home-hero__panel .eyebrow', 'color'),
        primaryButton: style('.home-hero__actions .btn--primary', 'backgroundColor'),
        buttonRadius: style('.home-hero__actions .btn--primary', 'borderTopLeftRadius'),
        cardRadius: style('.card', 'borderTopLeftRadius'),
        mediaRadius: style('.card__media', 'borderTopLeftRadius'),
        mediaFit: style('.card__media img', 'objectFit'),
        heroFit: style('.home-hero__photo img', 'objectFit'),
        searchRadius: style('.search-field', 'borderTopLeftRadius'),
        sectionFont: style('#home-novedades', 'fontWeight'),
        priceWeight: style('.card__price .price', 'fontWeight'),
      };
    });
    const expect = {
      canvas: 'rgb(255, 255, 255)',
      ink: 'rgb(17, 17, 17)',
      eyebrow: 'rgb(143, 104, 56)',
      primaryButton: 'rgb(17, 17, 17)',
      buttonRadius: '10px',
      cardRadius: '12px',
      mediaRadius: '8px',
      mediaFit: 'contain',
      heroFit: 'cover',
      sectionFont: '400',
      priceWeight: '700',
    };
    for (const [key, value] of Object.entries(expect)) assert(values[key] === value, `${key} is ${values[key]}, expected ${value}`);
    assert(Number.parseFloat(values.searchRadius) >= 24, `search field radius ${values.searchRadius}`);
    return JSON.stringify(values);
  });

  await report.step('D02', 'Wordmark is the app artwork at its own proportions', async () => {
    const logo = await page.evaluate(() => {
      const image = document.querySelector('.site-header .wordmark img');
      const rect = image.getBoundingClientRect();
      return { src: image.currentSrc, natural: [image.naturalWidth, image.naturalHeight], rendered: [rect.width, rect.height] };
    });
    assert(/logo-monetta(@[23]x)?\.png$/.test(logo.src), `logo source ${logo.src}`);
    const naturalRatio = logo.natural[0] / logo.natural[1];
    const renderedRatio = logo.rendered[0] / logo.rendered[1];
    assert(Math.abs(naturalRatio - renderedRatio) < 0.05, `ratio ${renderedRatio.toFixed(3)} vs ${naturalRatio.toFixed(3)}`);
    return `${logo.src.split('/').pop()} ${logo.natural.join('×')} rendered ${logo.rendered.map((value) => Math.round(value)).join('×')}`;
  });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${url}/`, { waitUntil: 'networkidle' });
  await report.step('D02', 'Selected dock item uses boutique gold with dark text', async () => {
    const dock = await page.evaluate(() => {
      const item = document.querySelector('.dock__item[aria-current="page"]');
      const style = getComputedStyle(item);
      return { background: style.backgroundColor, color: style.color, label: item.textContent.trim() };
    });
    assert(dock.background === 'rgb(197, 160, 82)', `dock background ${dock.background}`);
    assert(dock.color === 'rgb(23, 23, 21)', `dock text ${dock.color}`);
    return `${dock.label}: ${dock.background} / ${dock.color}`;
  });
  await context.close();
}
