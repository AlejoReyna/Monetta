// History bookkeeping behind the in-page back arrow: filters and sort push
// extra entries onto a screen (so the browser's Back restores them), and the
// arrow must leave the screen instead of stepping through them.
import assert from 'node:assert/strict';
import test from 'node:test';
import { nextHistoryState, screenBackSteps } from '../../src/lib/router.js';

const first = { scrollY: 0 };

test('a visit that began on this screen has nothing to go back to', () => {
  assert.equal(screenBackSteps(undefined), 0);
  assert.equal(screenBackSteps(first), 0);
  assert.equal(screenBackSteps({ idx: 0, entry: 0 }), 0);
});

test('opening another screen makes one step back leave it', () => {
  const state = nextHistoryState(first);
  assert.deepEqual(state, { scrollY: 0, idx: 1, entry: 1 });
  assert.equal(screenBackSteps(state), 1);
});

test('filter and sort entries stay inside the screen they belong to', () => {
  let state = nextHistoryState(first); // Home → collection
  state = nextHistoryState(state, { keep: true }); // filter
  state = nextHistoryState(state, { keep: true }); // sort
  assert.deepEqual(state, { scrollY: 0, idx: 3, entry: 1 });
  // The arrow skips both extra entries and lands on Home; Back would only undo the sort.
  assert.equal(screenBackSteps(state), 3);
});

test('the next screen starts its own run after filters', () => {
  let state = nextHistoryState(first);
  state = nextHistoryState(state, { keep: true });
  state = nextHistoryState(state); // collection → product
  assert.deepEqual(state, { scrollY: 0, idx: 3, entry: 3 });
  assert.equal(screenBackSteps(state), 1);
});

test('filters applied on the first screen of a visit still have nowhere to go back to', () => {
  let state = nextHistoryState(first, { keep: true });
  state = nextHistoryState(state, { keep: true });
  assert.deepEqual(state, { scrollY: 0, idx: 2, entry: 0 });
  assert.equal(screenBackSteps(state), 0);
});

test('replacing the entry (retry, variant) never moves the counters', () => {
  const state = nextHistoryState({ idx: 4, entry: 2 }, { replace: true });
  assert.deepEqual(state, { scrollY: 0, idx: 4, entry: 2 });
  assert.equal(screenBackSteps(state), 3);
});
